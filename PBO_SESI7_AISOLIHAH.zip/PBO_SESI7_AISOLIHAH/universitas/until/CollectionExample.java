package universitas.until;

import java.util.ArrayList;
import java.util.ArrayDeque;

public class CollectionExample {
    
    public static void main(String[] args) {
        // contoh penggunaan ArrayList dengan tipe data generik
        ArrayList<String> carBrands = new ArrayList<>();
        carBrands.add("Toyota");
        carBrands.add("Honda");
        carBrands.add("BMW");

        System.out.println("Daftar Merek Mobil:");
        for (String brand : carBrands) {
            System.out.println(brand);
        }

        // Contoh penggunaan ArrayDeque dengan tipe data generik
        ArrayDeque<String> carModels = new ArrayDeque<>();
        carModels.add("Corolla");
        carModels.add("Civic");
        carModels.add("X5");

        System.out.println("\nModel Mobil:");
        for (String model : carModels) {
            System.out.println(model);
        }
    }
}
